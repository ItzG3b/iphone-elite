#!/bin/sh
#
# Written by benanzo on 2007-OCT-23
#

# Virginizer working directory
VIRGINATOR_DIR=$(pwd)

# Secpacks
SECPACK_314="${VIRGINATOR_DIR}/314secpack"
SECPACK_401="${VIRGINATOR_DIR}/401secpack"

# EliteLoader
ELITELOADER="${VIRGINATOR_DIR}/eliteloader.bin"

# Global declarations
declare -rx SCRIPT=${0##*/}
declare -rx LAUNCHCTL="/bin/launchctl"
declare -rx NORZ="${VIRGINATOR_DIR}/norz"
declare -rx IUNLOCK="${VIRGINATOR_DIR}/iUnlock"
declare -rx BBUPDATER="${VIRGINATOR_DIR}/bbupdater"

###### Sanity checks
sanity_checks() {
echo "${SCRIPT}: ==== Beginnning sanity checks ===="
echo ""
echo ""
sleep 2
	# Check for launchctl
	echo "${SCRIPT}: Checking for launchctl..."
	sleep 2
	if [[ -x ${LAUNCHCTL} ]] ; then
		echo "${SCRIPT}: Found \"${LAUNCHCTL}\""
	else
		if [[ -f ${LAUNCHCTL} ]] ; then
			echo "${SCRIPT}: ERROR: \"${LAUNCHCTL}\" exists but is not executable."
			echo "This script needs to be run on an iPhone"
			echo "${SCRIPT}: Exiting now..."
			exit 1
		else
			echo "${SCRIPT}: ERROR: Cannot find \"launchctl\"."
			echo "This script needs to be run on an iPhone."
			echo "${SCRIPT}: Exiting now..."
			exit 1
		fi
	fi

	# Check for norz
	echo ""
	echo "${SCRIPT}: Checking for norz..."
	sleep 2
	if [[ -x ${NORZ} ]] ; then
		echo "${SCRIPT}: Found \"${NORZ}\"."
	else
		if [[ -f ${NORZ} ]] ; then
			chmod +x ${NORZ}
				if [[ -x ${NORZ} ]] ; then
					echo "${SCRIPT}: Found \"${NORZ}\"."
				else
					echo "${SCRIPT}: ERROR: Unable to make \"${NORZ}\" executable."
					echo "${SCRIPT}: Exiting now..."
					exit 1
				fi
		else
			echo "${SCRIPT}: ERROR: Cannot find \"norz\"."
			echo "${SCRIPT}: Exiting now..."
			exit 1
		fi
	fi

	# Check for iUnlock
	echo ""
	echo "${SCRIPT}: Checking for iUnlock..."
	sleep 2
	if [[ -x ${IUNLOCK} ]] ; then
		echo "${SCRIPT}: Found \"${IUNLOCK}\"."
	else
		if [[ -f ${IUNLOCK} ]] ; then
			chmod +x ${IUNLOCK}
				if [[ -x ${IUNLOCK} ]] ; then
					echo "${SCRIPT}: Found \"${IUNLOCK}\"."
				else
					echo "${SCRIPT}: ERROR: Unable to make \"${IUNLOCK}\" executable."
					echo "${SCRIPT}: Exiting now..."
					exit 1
				fi
		else
			echo "${SCRIPT}: ERROR: Cannot find \"iUnlock\"."
			echo "${SCRIPT}: Exiting now..."
			exit 1
		fi
	fi

	# Check for bbupdater
	echo ""
	echo "${SCRIPT}: Checking for bbupdater..."
	sleep 2
	if [[ -x ${BBUPDATER} ]] ; then
		echo "${SCRIPT}: Found \"${BBUPDATER}\"."
	else
		if [[ -f ${BBUPDATER} ]] ; then
			chmod +x ${BBUPDATER}
				if [[ -x ${BBUPDATER} ]] ; then
					echo "${SCRIPT}: Found \"${BBUPDATER}\"."
				else
					echo "${SCRIPT}: ERROR: Unable to make \"${BBUPDATER}\" executable."
					echo "${SCRIPT}: Exiting now..."
					exit 1
				fi
		else
			echo "${SCRIPT}: ERROR: Cannot find \"bbupdater\"."
			echo "${SCRIPT}: Exiting now..."
			exit 1
		fi
	fi

	# Check for 3.14 firmware
	echo ""
	echo "${SCRIPT}: Checking for 3.14 firmware files..."
	sleep 2
	if [[ -e "${VIRGINATOR_DIR}/ICE03.14.08_G.eep" ]] ; then
		echo "${SCRIPT}: Found \"${VIRGINATOR_DIR}/ICE03.14.08_G.eep\"."
	else
		echo "${SCRIPT}: ERROR: Cannot find \"ICE03.14.08_G.eep\"."
		echo "${SCRIPT}: Exiting now..."
		exit 1
	fi

	if [[ -e "${VIRGINATOR_DIR}/ICE03.14.08_G.fls" ]] ; then
		echo "${SCRIPT}: Found \"${VIRGINATOR_DIR}/ICE03.14.08_G.fls\"."
	else
		echo "${SCRIPT}: ERROR: Cannot find \"ICE03.14.08_G.fls\"."
		echo "${SCRIPT}: Exiting now..."
		exit 1
	fi

	# Check for eliteloader.bin
	echo ""
	echo "${SCRIPT}: Checking for eliteloader.bin..."
	sleep 2
	if [[ -e "${ELITELOADER}" ]] ; then
		echo "${SCRIPT}: Found \"${ELITELOADER}\"."
	else
		echo "${SCRIPT}: ERROR: Cannot find \"eliteloader.bin\"."
		echo "${SCRIPT}: Exiting now..."
		exit 1
	fi

	# Check for secpacks
	echo ""
	echo "${SCRIPT}: Checking for secpacks..."
	sleep 2
	if [[ -e "${SECPACK_314}" ]] ; then
		echo "${SCRIPT}: Found \"${SECPACK_314}\"."
	else
		echo "${SCRIPT}: ERROR: Cannot find \"314secpack\"."
		echo "${SCRIPT}: Exiting now..."
		exit 1
	fi

	if [[ -e "${SECPACK_401}" ]] ; then
		echo "${SCRIPT}: Found \"${SECPACK_401}\"."
	else
		echo "${SCRIPT}: ERROR: Cannot find \"401secpack\"."
		echo "${SCRIPT}: Exiting now..."
		exit 1
	fi
echo ""
echo ""
echo "${SCRIPT}: ==== All checks passed ===="
}

# Stop CommCenter
stop_commcenter() {
echo ""
echo ""
echo "${SCRIPT}: Stopping CommCenter..."
	sleep 2
	${LAUNCHCTL} unload -w /System/Library/LaunchDaemons/com.apple.CommCenter.plist
echo "${SCRIPT}: Done."
}

# Start CommCenter
start_commcenter() {
echo ""
echo ""
echo "${SCRIPT}: Starting CommCenter..."
	sleep 2
	${LAUNCHCTL} load -w /System/Library/LaunchDaemons/com.apple.CommCenter.plist
echo "${SCRIPT}: Done."
echo "${SCRIPT}: Exiting now..."
exit 0
}

# Backup the NOR seczone
backup_seczone() {
echo ""
echo ""
echo "Would you like to backup the seczone? (yes/no)"
read BACKUP_ANSWER
while [[ "${BACKUP_ANSWER}" != "yes" && "${BACKUP_ANSWER}" != "no" ]] ; do
	echo "${SCRIPT}: \"${BACKUP_ANSWER}\" is not a valid response."
	echo "${SCRIPT}: Please reply with \"yes\" or \"no\"."
	read BACKUP_ANSWER
done
if [[ ${BACKUP_ANSWER} = 'yes' ]] ; then
	echo "${SCRIPT}: Creating a backup of the NOR seczone..."
		${NORZ} seczone.backup 0x3FA000 0x2000
	echo "${SCRIPT}: Done.  Please copy \"seczone.backup\" to some place safe."
elif [[ ${BACKUP_ANSWER} = 'no' ]] ; then
	echo "Not backing up the seczone."
else
	echo "${SCRIPT}: ERROR: Invalid response."
	echo "${SCRIPT}: Exiting now..."
	exit 1
fi
}

# Virginize
virginize() {
echo ""
echo ""
echo "Would you like to virginize your seczone? (yes/no)"
read VIRGINIZE_ANSWER
while [[ "${VIRGINIZE_ANSWER}" != "yes" && "${VIRGINIZE_ANSWER}" != "no" ]] ; do
	echo "${SCRIPT}: \"${VIRGINIZE_ANSWER}\" is not a valid response."
	echo "${SCRIPT}: Please reply with \"yes\" or \"no\"."
	read VIRGINIZE_ANSWER
done
if [[ ${VIRGINIZE_ANSWER} = 'yes' ]] ; then
	echo "${SCRIPT}: Virginizing..."
		${IUNLOCK} ${VIRGINATOR_DIR}/ICE03.14.08_G.fls ${ELITELOADER}
	echo "${SCRIPT}: Done."
elif [[ ${VIRGINIZE_ANSWER} = 'no' ]] then
	echo "Not virginizing."
else 
	echo "${SCRIPT}: ERROR: Invalid response."
	echo "${SCRIPT}: Exiting now..."
	exit 1
fi

sleep 5
}

# Check baseband status
check_baseband() {
echo ""
echo ""
echo "${SCRIPT}: Checking baseband status..."
sleep 2
echo ""
${BBUPDATER} -v
}

# Reflash 3.14.08 baseband firmware
reflash_314_fw() {
echo ""
echo ""
echo "${SCRIPT}: You must reflash the 3.14.08 baseband firmware"
echo "${SCRIPT}: in order to complete the re-virginization process."
echo ""
echo "${SCRIPT}: Would you like to reflash the firmware? (yes/no)"
read REFLASH_ANSWER
while [[ "${REFLASH_ANSWER}" != "yes" && "${REFLASH_ANSWER}" != "no" ]] ; do
	echo "${SCRIPT}: \"${REFLASH_ANSWER}\" is not a valid response."
	echo "${SCRIPT}: Please reply with \"yes\" or \"no\"."
	read REFLASH_ANSWER
done
if [[ ${REFLASH_ANSWER} = 'yes' ]] ; then
	echo "${SCRIPT}: Reflashing..."
		${BBUPDATER} -f ${VIRGINATOR_DIR}/ICE03.14.08_G.fls -e ${VIRGINATOR_DIR}/ICE03.14.08_G.eep
	echo "${SCRIPT}: Done."
elif [[ ${REFLASH_ANSWER} = 'no' ]] ; then
	echo "Not reflashing the firmware."
else 
	echo "${SCRIPT}: ERROR: Invalid response."
	echo "${SCRIPT}: Exiting now..."
	exit 1
fi
}

echo ""
echo ""
echo "What do you want to do?"
echo "---"
echo "1) Just backup my seczone."
echo "2) Backup my seczone and re-virginize."
echo "---"
read CHOICE
while [[ "${CHOICE}" != "1" && "${CHOICE}" != "2" ]] ; do
	echo "${SCRIPT}: \"${CHOICE}\" is not a valid response."
	echo "${SCRIPT}: Please reply with \"1\" or \"2\"."
	read CHOICE
done
case ${CHOICE} in
    1 ) echo "${SCRIPT}: You chose just to backup your seczone."
	echo ""
	echo ""
	echo "${SCRIPT}: Starting..."
	sanity_checks
	stop_commcenter
	backup_seczone
	start_commcenter
        ;;
    2 ) echo "${SCRIPT}: You chose to backup your seczone and re-virginize."
	echo ""
	echo ""
	echo "${SCRIPT}: Starting..."
	sanity_checks
	stop_commcenter
	backup_seczone
	virginize
	check_baseband
	reflash_314_fw
	check_baseband
	start_commcenter	
        ;;
    * ) echo "${SCRIPT}: \"${CHOICE}\" is not a valid option."
	echo "${SCRIPT}: Please reply with \"1\" or \"2\"."
esac
