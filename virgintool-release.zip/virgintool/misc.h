#if !defined(_MISC_H_)
#define _MISC_H_

char *memcpy(char *destaddr, const char *srcaddr, int len);
void *memset(char *s, int c, int len);

#endif	/* !defined(_MISC_H_) */
