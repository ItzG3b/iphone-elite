#include<stdio.h>
#include<CoreFoundation/CoreFoundation.h>
#include<Foundation/Foundation.h>

void *_CTServerConnectionCreate(CFAllocatorRef allocator, int (*)(void *, CFStringRef, CFDictionaryRef, void *), int *);
//This is a horribly reversed prototype, perhaps when IDA recognizes the 
//arm instructions properly.
void  _CTServerConnectionEnableBrickMode(int *ioval, void* my_conn, int enordis);

int ctserv_cb(void *conn, CFStringRef string, CFDictionaryRef dict, void *dat)
{
  printf("callback called\n");
  return(0);
}

int main(int argc, char *argv[])
{
  void *my_conn;
  int enordis=0;

  printf("BrickTool 1.1.2 by\t79b1caf2c95695e0af0e6216216eec54, kiwi66\n");
  printf("\t\t\tBlaCkBirD, and b1llyb0y\n");

  if(argc > 1) {
    switch(argv[1][0])
    {
        case 'd':
          printf("[i] attempting to disable brick mode (enable phone)\n");
          enordis=0;
          break;
        case 'e':
          printf("[i] attempting to enable brick mode (disable phone)\n");
          enordis=1;
          break;
        default:
          printf("Example usage:\n");
          printf("%s d\n",argv[0]);
          printf("\tdisable brick mode (enable phone)\n");
          printf("%s e\n",argv[0]);
          printf("\tenable brick mode(disable phone)\n");
          printf("%s\n",argv[0]);
          printf("\tdisable brick mode (enable phone)\n");
          return(0);
          break;
    }
  } else {
    printf("[i] attempting to disable brick mode (enable phone)\n");
    enordis = 0;
  }

  int ioval[2];
  //unsigned char ioval2[128];

  memset(ioval,0x00, sizeof(ioval));
  //memset(ioval2, 0x00, sizeof(ioval2));

  my_conn = _CTServerConnectionCreate(CFAllocatorGetDefault(),ctserv_cb,ioval);
  if (my_conn == NULL)
  {
    printf("[e] couldn't establish core telephony connection\n");
    return(0);
  }
  _CTServerConnectionEnableBrickMode(ioval, my_conn, enordis);
  CFRelease(my_conn);
  printf("[i] success\n");
  return(0);
}
