#!/bin/sh

launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenter.plist

./norz seczone.backup 0x3FA000 0x2000
./iUnlock ICE03.14.08_G.fls eliteloader.bin
./bbupdater -v
./bbupdater -f ICE03.14.08_G.fls -e ICE03.14.08_G.eep
./bbupdater -v

launchctl load -w /System/Library/LaunchDaemons/com.apple.CommCenter.plist