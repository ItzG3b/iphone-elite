#!/bin/sh
#
# Virginator 0.4
#
#
# THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE
# COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM “AS IS” WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK
# AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL
# NECESSARY SERVICING, REPAIR OR CORRECTION.
#
#
#
# Virginator working directory
VIRGINATOR_DIR=$(pwd)
# Secpack
SECPACK_314="${VIRGINATOR_DIR}/314secpack"
# EliteLoader
ELITELOADER="${VIRGINATOR_DIR}/eliteloader.bin"
# Output file to check status
STATUS="${VIRGINATOR_DIR}/status"
# Error logs
ERROR_LOG="${VIRGINATOR_DIR}/error.log"

### Global declarations
declare -rx SCRIPT=${0##*/}
declare -rx LAUNCHCTL="/bin/launchctl"
declare -rx NORZ="${VIRGINATOR_DIR}/norz"
declare -rx IUNLOCK="${VIRGINATOR_DIR}/iUnlock"
declare -rx BBUPDATER="${VIRGINATOR_DIR}/bbupdater"

### Functions
# Sanity checks
sanity_checks() {
echo "==== Beginning sanity checks ===="
echo ""
echo ""
	# Check for BSD Subsystem
	echo "Checking for BSD Subsystem..."
	echo "-----"
	if [[ -x "/usr/bin/touch" ]] ; then
		echo "Found \"/usr/bin/touch\"."
	else
		echo "ERROR: Cannot find \"/usr/bin/touch\"."
		echo "ERROR: Please install the BSD Subsystem before running virginator.sh."
		echo "ERROR: Exiting now..."
		exit 1
	fi

	if [[ -x /bin/rm ]] ; then
		echo "Found \"/bin/rm\"."
	else
		echo "ERROR: Cannot find \"/bin/rm\"."
		echo "ERROR: Please install the BSD Subsystem before running virginator.sh."
		echo "ERROR: Exiting now..."
		exit 1
	fi

	if [[ -x /bin/chmod ]] ; then
		echo "Found \"/bin/chmod\"."
	else
		echo "ERROR: Cannot find \"/bin/chmod\"."
		echo "ERROR: Please install the BSD Subsystem before running virginator.sh."
		echo "ERROR: Exiting now..."
		exit 1
	fi

	if [[ -x /bin/sleep ]] ; then
		echo "Found \"/bin/sleep\"."
	else
		echo "ERROR: Cannot find \"/bin/sleep\"."
		echo "ERROR: Please install the BSD Subsystem before running virginator.sh."
		echo "ERROR: Exiting now..."
		exit 1
	fi

	if [[ -x /bin/cat ]] ; then
		echo "Found \"/bin/cat\"."
	else
		echo "ERROR: Cannot find \"/bin/cat\"."
		echo "ERROR: Please install the BSD Subsystem before running virginator.sh."
		echo "ERROR: Exiting now..."
		exit 1
	fi

	if [[ -x /usr/bin/grep ]] ; then
		echo "Found \"/usr/bin/grep\"."
	else
		echo "ERROR: Cannot find \"/usr/bin/grep\"."
		echo "ERROR: Please install the BSD Subsystem before running virginator.sh."
		echo "ERROR: Exiting now..."
		exit 1
	fi

	if [[ -x /usr/bin/find ]] ; then
		echo "Found \"/usr/bin/find\"."
	else
		echo "ERROR: Cannot find \"/usr/bin/find\"."
		echo "ERROR: Please install the BSD Subsystem before running virginator.sh."
		echo "ERROR: Exiting now..."
		exit 1
	fi

	if [[ -x /usr/bin/basename ]] ; then
		echo "Found \"/usr/bin/basename\"."
	else
		echo "ERROR: Cannot find \"/usr/bin/basename\"."
		echo "ERROR: Please install the BSD Subsystem before running virginator.sh."
		echo "ERROR: Exiting now..."
		exit 1
	fi
	echo "-----"
	echo "BSD Subsystem is installed."
	echo ""

	# Check for launchctl
	if [[ -x ${LAUNCHCTL} ]] ; then
		echo "Found \"${LAUNCHCTL}\"."
	else
		if [[ -e ${LAUNCHCTL} ]] ; then
			echo "ERROR: \"${LAUNCHCTL}\" exists but is not executable."
			echo "ERROR: Exiting now..."
			exit 1
		else
			echo "ERROR: Cannot find \"launchctl\"."
			echo "ERROR: Exiting now..."
			exit 1
		fi
	fi

	# Check for norz
	if [[ -x ${NORZ} ]] ; then
		echo "Found \"${NORZ}\"."
	elif [[ -e ${NORZ} ]] ; then
		chmod +x ${NORZ}
			if [[ -x ${NORZ} ]] ; then
				echo "Found \"${NORZ}\"."
			else
				echo "ERROR: Unable to make \"${NORZ}\" executable."
				echo "ERROR: Exiting now..."
				exit 1
			fi
	else
		echo "ERROR: Cannot find \"norz\"."
		echo "ERROR: Exiting now..."
		exit 1
	fi

	# Check for iUnlock
	if [[ -x ${IUNLOCK} ]] ; then
		echo "Found \"${IUNLOCK}\"."
	elif [[ -e ${IUNLOCK} ]] ; then
		chmod +x ${IUNLOCK}
			if [[ -x ${IUNLOCK} ]] ; then
				echo "Found \"${IUNLOCK}\"."
			else
				echo "ERROR: Unable to make \"${IUNLOCK}\" executable."
				echo "ERROR: Exiting now..."
				exit 1
			fi
	else
		echo "ERROR: Cannot find \"iUnlock\"."
		echo "ERROR: Exiting now..."
		exit 1
	fi

	# Check for bbupdater
	if [[ -x ${BBUPDATER} ]] ; then
		echo "Found \"${BBUPDATER}\"."
	elif [[ -e ${BBUPDATER} ]] ; then
		chmod +x ${BBUPDATER}
			if [[ -x ${BBUPDATER} ]] ; then
				echo "Found \"${BBUPDATER}\"."
			else
				echo "ERROR: Unable to make \"${BBUPDATER}\" executable."
				echo "ERROR: Exiting now..."
				exit 1
			fi
	else
		echo "ERROR: Cannot find \"bbupdater\"."
		echo "ERROR: Exiting now..."
		exit 1
	fi

	# Check for 3.14 firmware
	if [[ -e "${VIRGINATOR_DIR}/ICE03.14.08_G.eep" ]] ; then
		echo "Found \"${VIRGINATOR_DIR}/ICE03.14.08_G.eep\"."
	else
		echo "ERROR: Cannot find \"ICE03.14.08_G.eep\"."
		echo "ERROR: Exiting now..."
		exit 1
	fi

	if [[ -e "${VIRGINATOR_DIR}/ICE03.14.08_G.fls" ]] ; then
		echo "Found \"${VIRGINATOR_DIR}/ICE03.14.08_G.fls\"."
	else
		echo "ERROR: Cannot find \"ICE03.14.08_G.fls\"."
		echo "ERROR: Exiting now..."
		exit 1
	fi

	# Check for eliteloader.bin
	if [[ -e "${ELITELOADER}" ]] ; then
		echo "Found \"${ELITELOADER}\"."
	else
		echo "ERROR: Cannot find \"eliteloader.bin\"."
		echo "ERROR: Exiting now..."
		exit 1
	fi

	# Check for secpack
	if [[ -e "${SECPACK_314}" ]] ; then
		echo "Found \"${SECPACK_314}\"."
	else
		echo "ERROR: Cannot find \"314secpack\"."
		echo "ERROR: Exiting now..."
		exit 1
	fi
echo ""
echo ""
echo "==== All checks passed ===="
echo ""
echo ""

# Cleanup previous status files and error logs
for ERROR_LOG_NAME in $(find ${VIRGINATOR_DIR} -name "error.log") ; do
	COUNT="1"
	while [[ -e ${ERROR_LOG_NAME}_${COUNT} ]] ; do
		COUNT=$((COUNT + 1))
	done
		ERROR_LOG_NEW_NAME="${ERROR_LOG_NAME}_${COUNT}"
		mv "${ERROR_LOG_NAME}" "${ERROR_LOG_NEW_NAME}"
		echo ""
		echo "-----"
		echo "Old \"${ERROR_LOG_NAME}\" has been renamed to \"$(basename ${ERROR_LOG_NEW_NAME})\"."
done

if [[ -e ${STATUS} ]] ; then
	rm ${STATUS}
fi
}

# Stop CommCenter
stop_commcenter() {
echo ""
echo ""
echo "Stopping CommCenter..."
	${LAUNCHCTL} unload -w /System/Library/LaunchDaemons/com.apple.CommCenter.plist
		sleep 2
		if [[ -e ${STATUS} ]] ; then
			rm ${STATUS}
		fi
		${LAUNCHCTL} unload -w /System/Library/LaunchDaemons/com.apple.CommCenter.plist >& ${STATUS}
			if [[ $(cat ${STATUS}) = "No such process" ]] ; then
				echo "Done."
			else
				echo "ERROR: Unable to stop CommCenter."
				echo "ERROR: Exiting now..."
				exit 1
			fi
}

# Start CommCenter and exit virginator
start_commcenter() {
echo ""
echo ""
echo "Starting CommCenter..."
	${LAUNCHCTL} load -w /System/Library/LaunchDaemons/com.apple.CommCenter.plist
		sleep 2
		if [[ -e ${STATUS} ]] ; then
			rm ${STATUS}
		fi
		${LAUNCHCTL} load -w /System/Library/LaunchDaemons/com.apple.CommCenter.plist >& ${STATUS}
			if [[ $(cat ${STATUS}) = "com.apple.CommCenter: Already loaded" ]] ; then
				echo "Done."
			else
				echo "ERROR: Unable to start Commcenter."
				echo "ERROR: Exiting now..."
				exit 1
			fi
echo "Exiting now..."
exit 0
}

# Backup the NOR seczone
backup_seczone() {
echo ""
echo ""
echo "Would you like to start the backup process? (yes/no)"
read BACKUP_ANSWER
	while [[ ${BACKUP_ANSWER} != 'yes' && ${BACKUP_ANSWER} != 'no' ]] ; do
		echo "\"${BACKUP_ANSWER}\" is not a valid response."
		echo "Please reply with \"yes\" or \"no\"."
		read BACKUP_ANSWER
	done
if [[ ${BACKUP_ANSWER} = 'yes' ]] ; then
	if [[ -e ${VIRGINATOR_DIR}/seczone.backup ]] ; then
		echo ""
		echo "-----"
		echo "There is already a file called \"seczone.backup\""
		echo "in this directory."
		echo "-----"
		echo "Would you like to rename it so you can create a new backup? (yes/no)"
		read RENAME_ANSWER
			while [[ ${RENAME_ANSWER} != 'yes' && ${RENAME_ANSWER} != 'no' ]] ; do
				echo "\"${RENAME_ANSWER}\" is not a valid response."
				echo "Please reply with \"yes\" or \"no\"."
				read RENAME_ANSWER
			done
		if [[ ${RENAME_ANSWER} = 'yes' ]] ; then
			for NAME in $(find ${VIRGINATOR_DIR} -name "seczone.backup") ; do
				COUNT="1"
       					while [[ -e ${NAME}_${COUNT} ]] ; do
						COUNT=$((COUNT + 1))
        				done
    				NEW_NAME="${NAME}_${COUNT}"
					mv "${NAME}" "${NEW_NAME}"
					echo ""
					echo "-----"
					echo "\"seczone.backup\" has been renamed to \"$(basename ${NEW_NAME})\"."
			done
		elif [[ ${RENAME_ANSWER} = 'no' ]] ; then
			echo "Not renaming \"seczone.backup\"."
			echo "Continuing..."
		else
			echo "ERROR: Invalid response."
			echo "ERROR: Exiting now..."
			exit 1
		fi
	fi
	echo "Creating a backup of the NOR seczone..."
	${NORZ} seczone.backup 0x3FA000 0x2000
			if [[ -e "${VIRGINATOR_DIR}/seczone.backup" ]] ; then
				echo ""
				echo "-----"
				echo "\"${VIRGINATOR_DIR}/seczone.backup\" created"
				echo "successfully.  Please copy it to some place safe."
				echo "-----"
			else
				echo "Unable to create \"${VIRGINATOR_DIR}/seczone.backup\"."
			fi
elif [[ ${BACKUP_ANSWER} = 'no' ]] ; then
	echo "Not backing up the seczone."
else
	echo "ERROR: Invalid response."
	echo "ERROR: Exiting now..."
	exit 1
fi
}

# Virginize
virginize() {
echo ""
echo ""
echo "Would you like to virginize your seczone? (yes/no)"
read VIRGINIZE_ANSWER
while [[ "${VIRGINIZE_ANSWER}" != 'yes' && "${VIRGINIZE_ANSWER}" != 'no' ]] ; do
	echo "\"${VIRGINIZE_ANSWER}\" is not a valid response."
	echo "Please reply with \"yes\" or \"no\"."
	read VIRGINIZE_ANSWER
done
if [[ ${VIRGINIZE_ANSWER} = 'yes' ]] ; then
	echo "Virginizing..."
	${IUNLOCK} ${VIRGINATOR_DIR}/ICE03.14.08_G.fls ${ELITELOADER}
	echo "Done."
elif [[ ${VIRGINIZE_ANSWER} = 'no' ]] ; then
	echo "Not virginizing."
	start_commcenter
else 
	echo "ERROR: Invalid response."
	echo "ERROR: Exiting now..."
	exit 1
fi
}

# Check baseband status
check_baseband() {
echo ""
echo ""
echo "Checking baseband status..."
echo ""
	if [[ -e ${STATUS} ]] ; then
		rm ${STATUS}
	fi
${BBUPDATER} -v >& ${STATUS}
}

# Reflash 3.14.08 baseband firmware
reflash_314_fw() {
if [[ ${VIRGINIZE_ANSWER} = 'yes' ]] ; then
	echo ""
	echo ""
	echo "-----"
	echo "You must reflash the 3.14.08 baseband firmware"
	echo "in order to complete the re-virginization process."
	echo "-----"
	echo "Would you like to reflash the firmware? (yes/no)"
	read REFLASH_ANSWER
	while [[ "${REFLASH_ANSWER}" != 'yes' && "${REFLASH_ANSWER}" != 'no' ]] ; do
		echo "\"${REFLASH_ANSWER}\" is not a valid response."
		echo "Please reply with \"yes\" or \"no\"."
		read REFLASH_ANSWER
	done
	if [[ ${REFLASH_ANSWER} = 'yes' ]] ; then
		echo "Reflashing..."
		${BBUPDATER} -f ${VIRGINATOR_DIR}/ICE03.14.08_G.fls -e ${VIRGINATOR_DIR}/ICE03.14.08_G.eep
		echo "Done."
	elif [[ ${REFLASH_ANSWER} = 'no' ]] ; then
		echo "Not reflashing the firmware."
	else 
		echo "ERROR: Invalid response."
		echo "ERROR: Exiting now..."
		exit 1
	fi
elif [[ ${VIRGINIZE_ANSWER} = 'no' ]] ; then
	echo "No need to reflash the 3.14.08 firmware."
	start_commcenter
else 
	echo "ERROR: Invalid status."
	echo "ERROR: Exiting now..."
	exit 1
fi
}

# ERROR for unsuccessful virginizing
virgin_error() {
cat >> ${ERROR_LOG} << _EOF_
==================
ERROR: There was a problem with virginizing.
ERROR: The status return was different than expected.
ERROR: The following is the current output of "bbupdater -v":
----------
$(cat ${STATUS})
----------
ERROR: It should be:
----------
Resetting target...
pinging the baseband...
baseband unresponsive to pinging
Done
----------
ERROR: Please visit:
ERROR: http://code.google.com/p/iphone-elite/wiki/RevirginizingTool
==================
_EOF_
}

# ERROR for unsuccessful reflashing
reflash_error() {
cat >> ${ERROR_LOG} << _EOF_
==================
ERROR: There was a problem reflashing the firmware.
ERROR: The status return was different than expected.
ERROR: The following is the current output of "bbupdater -v":
----------
$(cat ${STATUS})
----------
ERROR: It should be:
----------
Resetting target...
pinging the baseband...
issuing +xgendata...
firmware: DEV_ICE_MODEM_03.14.08_G
eep version: EEP_VERSION:207
eep revision: EEP_REVISION:7
bootloader: BOOTLOADER_VERSION:3.9_M3S2
Done
----------
ERROR: Please visit:
ERROR: http://code.google.com/p/iphone-elite/wiki/RevirginizingTool
==================
_EOF_
}

# Start the virginator menu
start_virginator() {
echo ""
echo ""
echo "What do you want to do?"
echo "---"
echo "1) Just backup my seczone."
echo "2) Backup my seczone and re-virginize."
echo "---"
read CHOICE
while [[ "${CHOICE}" != '1' && "${CHOICE}" != '2' ]] ; do
	echo "\"${CHOICE}\" is not a valid option."
	echo "Please reply with \"1\" or \"2\"."
	read CHOICE
done
case ${CHOICE} in
    1 ) echo "You chose just to backup your seczone."
	echo ""
	echo ""
	echo "Starting..."
	sanity_checks
	stop_commcenter
	backup_seczone
	start_commcenter
        ;;
    2 ) echo "You chose to backup your seczone and re-virginize."
	echo ""
	echo ""
	echo "Starting..."
	sanity_checks
	stop_commcenter
	backup_seczone
	virginize
	check_baseband
		if [[ ${VIRGINIZE_ANSWER} = 'no' ]] ; then
			echo "No virginizing modifications were made."
			start_commcenter
		elif [[ $(cat ${STATUS} | grep "unresponsive") = "baseband unresponsive to pinging" ]] ; then
			echo "Your seczone should now be repaired."
		else
			virgin_error
			echo "ERROR: There was a problem with virginizing."
			echo "ERROR: The status return was different than expected."
			echo "-----"
			echo "More details on this error are stored in ${ERROR_LOG}"
			echo ""
			start_commcenter
		fi
	reflash_314_fw
	check_baseband
		if [[ ${REFLASH_ANSWER} = 'no' ]] ; then
			echo "No reflashing was done."
		elif [[ $(cat ${STATUS} | grep "03.14.08_G") = "    firmware: DEV_ICE_MODEM_03.14.08_G" ]] ; then
			echo "Successfully reflashed baseband firmware to 3.14.08."
		else
			reflash_error
			echo "ERROR: There was a problem reflashing the firmware."
			echo "ERROR: The status return was different than expected."
			echo "-----"
			echo "More details on this error are stored in ${ERROR_LOG}"
			echo ""
		fi
	start_commcenter	
        ;;
    * ) echo "\"${CHOICE}\" is not a valid option."
	echo "Please reply with \"1\" or \"2\"."
esac
}

# Welcome
echo ""
echo "Welcome to virginator!"
echo ""
echo "-----WARNING-----"
echo "It is very important to be connected to a reliable"
echo "power source during this process.  If your phone"
echo "powers off or reboots during a critical operation"
echo "it could become permanently damaged."
echo "-----------------"
echo "Is it safe to continue?"
echo "---"
echo "1) Yes, please continue."
echo "2) No, please exit."
echo "---"
read WELCOME_ANSWER
while [[ "${WELCOME_ANSWER}" != '1' && "${WELCOME_ANSWER}" != '2' ]] ; do
	echo "\"${WELCOME_ANSWER}\" is not a valid response."
	echo "Please reply with \"1\" or \"2\"."
	read WELCOME_ANSWER
done
if [[ ${WELCOME_ANSWER} = '1' ]] ; then
	echo "Starting virginator..."
		start_virginator	
elif [[ ${WELCOME_ANSWER} = '2' ]] ; then
	echo "Exiting now..."
	exit 0
else 
	echo "ERROR: Invalid response."
	echo "Exiting now..."
	exit 1
fi
